import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CreateflightRoutingModule } from './createflight-routing.module';
import { CreateflightComponent } from './createflight/createflight.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';


@NgModule({
  declarations: [CreateflightComponent],
  imports: [
    CommonModule,
    CreateflightRoutingModule,
    ReactiveFormsModule,
    FormsModule
  ]
})
export class CreateflightModule { }
