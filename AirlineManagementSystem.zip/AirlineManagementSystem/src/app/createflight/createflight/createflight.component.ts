import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators} from '@angular/forms';
import { Title } from '@angular/platform-browser';
import { Router } from '@angular/router';
import { AirlineCRUDService } from 'src/app/airline-crud.service';
import { AirlinesData, AirlineService } from 'src/app/airline.service';

@Component({
  selector: 'app-createflight',
  templateUrl: './createflight.component.html',
  styleUrls: ['./createflight.component.css']
})
export class CreateflightComponent implements OnInit {
  title:string="Create Flight";
  formdata:any;
  pname:string;
  pcode:string="";
  ptype:string;
  airlinecrudservice:AirlineCRUDService;

  constructor(private changeTitle:Title,private a1:AirlineCRUDService,private router:Router) { }

  ngOnInit(){
    this.changeTitle.setTitle(this.title);
    this.formdata=new FormGroup({
      pname:new FormControl(
        "",
        Validators.compose([
          Validators.required,
          Validators.pattern("^[A-Za-z ]+"),
          Validators.maxLength(10)
        ])
      ),
      ptype:new FormControl(
        "",
        Validators.compose([
          Validators.required,
          Validators.pattern("^[A-Za-z]+"),
          Validators.maxLength(13)
        ])
      )
    });
  }
  getValue(data){
    if(data.toLowerCase()=='indigo')
      this.pcode='6E-';
    else if(data.toLowerCase()=='spicejet')
      this.pcode='SG-';
    else if(data.toLowerCase()=='air asia')
      this.pcode='I5-';
    else if(data.toLowerCase()=='go air')
      this.pcode='G8-';
    else if(data.toLowerCase()=='jet airways')
      this.pcode='9W-';
    else if(data.toLowerCase()=='air india')
      this.pcode='AI-';
    else
      this.pcode='';
  }
  onClickSubmit(data){
    this.pname=data.pname;
    this.ptype=data.ptype;
    let airline=new AirlinesData(null,this.pname,this.pcode,this.ptype);
    this.a1.addairline(airline).subscribe(()=>{
      this.router.navigate(['/'])
    });
    this.a1.getairline().subscribe((res:AirlinesData[])=>
      console.log(res)
    )
  }
}
