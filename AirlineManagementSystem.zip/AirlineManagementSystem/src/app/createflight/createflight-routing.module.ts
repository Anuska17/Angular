import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CreateflightComponent } from './createflight/createflight.component';

const routes: Routes = [
  {path:'',component:CreateflightComponent}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class CreateflightRoutingModule { }
