import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { DeleteflightRoutingModule } from './deleteflight-routing.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { DeleteflightComponent } from './deleteflight/deleteflight.component';


@NgModule({
  declarations: [DeleteflightComponent],
  imports: [
    CommonModule,
    DeleteflightRoutingModule,
    FormsModule,
    ReactiveFormsModule
  ]
})
export class DeleteflightModule { }
