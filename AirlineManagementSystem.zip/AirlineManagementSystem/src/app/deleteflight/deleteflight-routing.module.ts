import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { DeleteflightComponent } from './deleteflight/deleteflight.component';


const routes: Routes = [
  {path:'',component:DeleteflightComponent},
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class DeleteflightRoutingModule { }
