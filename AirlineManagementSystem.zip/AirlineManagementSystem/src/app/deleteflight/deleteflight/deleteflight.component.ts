import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Title } from '@angular/platform-browser';
import { Router } from '@angular/router';
import { AirlineCRUDService } from 'src/app/airline-crud.service';
import { AirlinesData } from 'src/app/airline.service';

@Component({
  selector: 'app-deleteflight',
  templateUrl: './deleteflight.component.html',
  styleUrls: ['./deleteflight.component.css']
})
export class DeleteflightComponent implements OnInit {

  title:string="Delete Flight";
  airline:AirlinesData[];
  formdata:any;
  pcode:string;
  ptype:string;
  id:number;
  checkpcode:string;
  flag:boolean;
  notfound:boolean=false;
  
  constructor(private changeTitle:Title,private a1:AirlineCRUDService,private router:Router) { }

  ngOnInit(): void {
    this.changeTitle.setTitle(this.title);
    this.a1.getairline().subscribe((res:AirlinesData[])=>{
      this.airline=res;
    }); 
    this.formdata=new FormGroup({
      pcode:new FormControl(
        "",
        Validators.compose([
          Validators.required,
          Validators.pattern("^[A-Z0-9-]+"),
          Validators.maxLength(3)
        ])
      ),
      ptype:new FormControl(
        "",
        Validators.compose([
          Validators.required,
          Validators.pattern("^[A-Za-z]+"),
          Validators.maxLength(13)
        ])
      )
    });
  }

  checkCode(){
    var i;
    for(i=0;i<this.airline.length;i++){
      if(this.airline[i].providerCode==this.checkpcode){
        this.flag=true;
        this.notfound=false;
        break;
      }
      else
        this.flag=false;
    }
  }

  onClickSubmit(data){
    var i;
    for(i=0;i<this.airline.length;i++){
      if(this.airline[i].providerCode==data.pcode&&this.airline[i].providerType==data.ptype){
        this.id=this.airline[i].id;
        this.a1.deleteairline(this.id).subscribe(()=>{
          this.router.navigate(['/'])
        });
        break;
      }
      else
        this.notfound=true;
    }
  }
}
