import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { AirlinesData } from './airline.service';

@Injectable({
  providedIn: 'root'
})
export class AirlineCRUDService {

  constructor(private httpclient:HttpClient) { }

  addairline(airline:AirlinesData){
    return this.httpclient.post('api/airlines',airline);
  }

  deleteairline(id:number){
    return this.httpclient.delete('api/airlines/'+id);
  }

  getairline():Observable<AirlinesData[]>{
    return this.httpclient.get<AirlinesData[]>('api/airlines');
  }

  updateairline(airlinedata:AirlinesData){
    return this.httpclient.post(`api/airlines`,airlinedata);
  }

}
