import { Component, OnInit } from '@angular/core';
import { Title } from '@angular/platform-browser';
import { AirlineCRUDService } from 'src/app/airline-crud.service';
import { AirlinesData } from 'src/app/airline.service';

@Component({
  selector: 'app-viewflight',
  templateUrl: './viewflight.component.html',
  styleUrls: ['./viewflight.component.css']
})
export class ViewflightComponent implements OnInit {

  title:string="View AirlineProviders Information";
  airline:AirlinesData[];
  typeFilter:string;
  condition:boolean;

  constructor(private changeTitle:Title,private a1:AirlineCRUDService) { }

  ngOnInit(): void {
    this.changeTitle.setTitle(this.title);
    this.a1.getairline().subscribe((res:AirlinesData[])=>{
      this.airline=res;
    })
    
  }
  changeCondition(){
    if(this.typeFilter=="")
      this.condition=false;
    else
      this.condition=true;
  }
}
