import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ViewflightRoutingModule } from './viewflight-routing.module';
import { ViewflightComponent } from './viewflight/viewflight.component';
import { ViewflightPipe } from './viewflight.pipe';
import { FormsModule } from '@angular/forms';


@NgModule({
  declarations: [ViewflightComponent, ViewflightPipe],
  imports: [
    CommonModule,
    ViewflightRoutingModule,
    FormsModule
  ]
})
export class ViewflightModule { }
