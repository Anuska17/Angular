import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ViewflightComponent } from './viewflight/viewflight.component';

const routes: Routes = [
  {path:'',component:ViewflightComponent}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ViewflightRoutingModule { }
