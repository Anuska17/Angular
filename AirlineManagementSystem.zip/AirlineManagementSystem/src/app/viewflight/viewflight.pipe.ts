import { Pipe, PipeTransform } from '@angular/core';
import { AirlinesData } from '../airline.service';

@Pipe({
  name: 'viewflight'
})
export class ViewflightPipe implements PipeTransform {

  transform(param1: AirlinesData[], param2: string): AirlinesData[] {
    if(!param2) return [];
    var search=param2.toLowerCase();
    return param1.filter((a)=>{
      return a.providerType.toLowerCase().startsWith(search);
    });
  }
}
