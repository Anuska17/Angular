import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Title } from '@angular/platform-browser';
import { Router } from '@angular/router';
import { AirlineCRUDService } from 'src/app/airline-crud.service';
import { AirlinesData } from 'src/app/airline.service';

@Component({
  selector: 'app-updateflight',
  templateUrl: './updateflight.component.html',
  styleUrls: ['./updateflight.component.css']
})
export class UpdateflightComponent implements OnInit {

  title:string="Update Flight Details";
  airline:AirlinesData[];
  formdata:any;
  pcode:string;
  ptype:string;
  pname:string;
  id:number;
  checkpcode:string;
  flag:boolean;
  notfound:boolean;
  
  constructor(private changeTitle:Title,private a1:AirlineCRUDService,private router:Router) { }

  ngOnInit(): void {
    this.changeTitle.setTitle(this.title);
    this.a1.getairline().subscribe((res:AirlinesData[])=>{
      this.airline=res
    });
    this.formdata=new FormGroup({
      pcode:new FormControl(
        "",
        Validators.compose([
          Validators.required,
          Validators.pattern("^[A-Z0-9-]+"),
          Validators.maxLength(3)
        ])
      ),
      ptype:new FormControl(
        "",
        Validators.compose([
          Validators.required,
          Validators.pattern("^[A-Za-z]+"),
          Validators.maxLength(13)
        ])
      )
    });
  }

  checkCode(){
    var i;
    for(i=0;i<this.airline.length;i++){
      if(this.airline[i].providerCode==this.checkpcode){
        this.flag=true;
        this.notfound=false;
        break;
      }
      else
        this.flag=false;
    }
  }

  onClickSubmit(data){
    var i;
    for(i=0;i<this.airline.length;i++){
      if(this.airline[i].providerCode==data.pcode){
        if(this.airline[i].providerType!=data.ptype){
          let a2=new AirlinesData(this.airline[i].id,this.airline[i].providerName,data.pcode,data.ptype);
          this.a1.updateairline(a2).subscribe(()=>{
            this.router.navigate(['/'])
          })
        }
        else
          this.notfound=true;
        break;
      }
    }  
  }
}
