import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { UpdateflightRoutingModule } from './updateflight-routing.module';
import { UpdateflightComponent } from './updateflight/updateflight.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';


@NgModule({
  declarations: [UpdateflightComponent],
  imports: [
    CommonModule,
    UpdateflightRoutingModule,
    FormsModule,
    ReactiveFormsModule
  ]
})
export class UpdateflightModule { }
