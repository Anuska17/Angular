import { Injectable } from '@angular/core';
import { InMemoryDbService} from 'angular-in-memory-web-api';

@Injectable({
  providedIn: 'root'
})
export class AirlineService implements InMemoryDbService{

  constructor() { }
  createDb(){
    let airlines=[
      new AirlinesData(1,'Jet Airways','9W-','Domestic'),
      new AirlinesData(2,'Emirates','EK-','International'),
    ];
    return {airlines};
  }

  /*genId(airlines:AirlinesData[]):number{
    return airlines.length>0?Math.max(...airlines.map(airline => airline.id)) + 1 : 1;
  }*/

  
}

export class AirlinesData{
  id:number;
  providerName:string;
  providerCode:string;
  providerType:string;

  constructor(id:number,providerName:string,providerCode:string,providerType:string){
    this.id=id;
    this.providerName=providerName;
    this.providerCode=providerCode;
    this.providerType=providerType;
  }
}

