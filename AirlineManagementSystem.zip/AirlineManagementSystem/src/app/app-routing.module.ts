import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

const routes: Routes = [
  {path:'create',loadChildren:()=>import('./createflight/createflight.module').then(mod => mod.CreateflightModule)},
  {path:'read',loadChildren:()=>import('./viewflight/viewflight.module').then(mod => mod.ViewflightModule)},
  {path:'delete',loadChildren:()=>import('./deleteflight/deleteflight.module').then(mod => mod.DeleteflightModule)},
  {path:'update',loadChildren:()=>import('./updateflight/updateflight.module').then(mod => mod.UpdateflightModule)}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
