import { Component } from '@angular/core';
import { trigger,state,style,transition,animate} from '@angular/animations';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  animations:[
    trigger('flyInOut',[
      state("void",style(
        {opacity:0, transform: 'translateX(-10%)', offset:0}
      )),
      state("*",style(
        {opacity:1, transform: 'translateX(1200px)', offset:0}
      )),
      transition('void => *',[animate('5000ms 4000ms')]),
      transition('* => void',[animate('5000ms 4000ms')]),    
    ])
  ]
})
export class AppComponent {
  title = 'Assignment4';
  showDiv:boolean=false;
  toggleDiv():void{
    this.showDiv=this.showDiv?false:true;
  }
}
